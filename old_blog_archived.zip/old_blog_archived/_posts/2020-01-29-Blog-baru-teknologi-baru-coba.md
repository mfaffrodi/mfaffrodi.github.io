---
layout: post
section-type: post
title: Welcome to MFAffrodi Blog!
category: tech
tags: [ 'tutorial' ]
---

Just trying a new way making blog using Jekyll
